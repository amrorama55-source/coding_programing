let img = document.querySelector(".img");
let container = document.querySelector(".container");

function phones(phones){
    img.src=  phones;;
}

function colors(colors){
container.style.background = colors;
}